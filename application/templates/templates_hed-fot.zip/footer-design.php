		<div id="caja"></div>
<!-- 		<script>
		$(function () {
			document.title = (($.trim($('[data-header]:first').text()) != '') ? $.trim(document.title.split('::')[0]) + ' :: ' + $.trim($('[data-header]:first').text()) : document.title);
			/*$(document).on('contextmenu selectstart dragstart', function (e) { e.preventDefault(); });
			$('body').css({ cursor: 'default' });*/
		});
		</script> -->
		<script>

$(function () { 

    <?php if ($_clock == 's') : ?>
    var date, time, hours, minutes, seconds, tseconds, tminutes, thours;

    $.ajax({
        type: 'post',
        dataType: 'json',
        url: '?/principal/reloj'
    }).done(function (datetime) {

        date = datetime.date;
        hours = parseInt(datetime.hours);
        minutes = parseInt(datetime.minutes);
        seconds = parseInt(datetime.seconds);

    }).fail(function () {
        date = moment().format('YYYY-MM-DD');
        hours = parseInt(moment().format('H'));
        minutes = parseInt(moment().format('mm'));
        seconds = parseInt(moment().format('ss'));

    });

    setInterval(function () {

        if (seconds < 59) {
            seconds = seconds + 1;
        } else {
            seconds = 0;
            if (minutes < 59) {
                minutes = minutes + 1;
            } else {
                minutes = 0;
                if (hours < 23) {
                    hours = hours + 1;
                } else {
                    hours = 0;
                }
            }
        }

        tseconds = (seconds < 10) ? '0' + seconds : seconds;
        tminutes = (minutes < 10) ? '0' + minutes : minutes;
        thours = (hours < 10) ? '0' + hours : hours;
        time = thours + ':' + tminutes + ':' + tseconds

        $('[data-datetime="date"]').text(date);
        $('[data-datetime="time"]').text(time);

    }, 1000);
    <?php endif ?>
    
    // setInterval(function () {
    //     $.ajax({
    //         type: 'post',
    //         dataType: 'json',
    //         url: '?/principal/suspender-app'
    //     }).done(function (data) {
    //         $('#caja').find('h2').text(data);
    //     });
    // }, 500);
    
});
</script>


  <!-- <script src="assets/themes/concept/assets/vendor/alertify/js/alertify.min.js"></script> -->
  <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/7.2.3/firebase-firestore.js"></script>


<!-- <input type="text" id="cc_msg_new" value="0"/>-->
 <input type="hidden" value="<?=$_user['persona_id']?>" id="inp_id_user"> 
 <input type="hidden" value="<?=$_user['rol_id']?>" id="inp_rol_user"> 

<script>

var idfirebase='';  
var idusuario='';  
firebase.initializeApp({
  apiKey: "AIzaSyD1QBf-5QfF3O4dsfwCYpDFAjhZHii73jE",
  authDomain: "prueba-14cc3.firebaseapp.com",
  projectId: "prueba-14cc3"
});

var db = firebase.firestore();

 db.collection("users").onSnapshot((querySnapshot) => {
    querySnapshot.forEach((doc) => {
    $('.notification-list').html('<div class=" text-center"><b>Sin mensajes disponibles</b></div>'); 
        idfirebase=`${doc.id}`;//id para todo el sistema
        rol_id=`${doc.data().rol_id}`;//id para todo el sistema
        titulo=`${doc.data().titulo}`;//id para todo el sistema
        desc=`${doc.data().desc}`;//id para todo el sistema
        fecha=`${doc.data().fecha}`;//id para todo el sistema
        personas_id=`${doc.data().personas_id}`;//id para todo el sistema
        //listar notificaciones1 manda consulta son solo de sus usuario
        iniciar(rol_id,titulo,desc,fecha,personas_id);
    });
});

 //en caso de inicio sin datos iniciales en firebase
function crearbdfirebase(){    
       //if(ini<1){
         alert('CREANDO NUEVO');
         //CREAR a firestore//:::::::::::::::::::::::
        db.collection("users").add({
            titulo: 'titulo',
            desc: 'descripcion',
            fecha: 'fecha',
            rol_id: 'rol_id',
            id_comunicado:'id_comunicado',
            personas_id:'1'
        })
        .then(function(docRef) {
            //console.log("EXITO Document CREADO   ID: ", docRef.id); 
        })
        .catch(function(error) {
            //console.error("Error adding document: ", error);
        });         
}

//al momento de editar o crear comunicado se llama esta funcion
 function notificarfire(titulo,descripcion,fecha,rol_id,id_comunicado,personas_id){
    var washingtonRef=  db.collection("users").doc(idfirebase);
    return washingtonRef.update({
            titulo:titulo,
            desc: descripcion, 
            rol_id: rol_id, 
            personas_id: personas_id, 
            fecha: fecha, 
            id_comunicado: id_comunicado
         }).then(function(){
             //console.log('Editado succesfull firebase');              
         }).catch(function(error){
            // console.log('error',error);
         }); 
 }
  
 //lista las notificaciones en html 
var cc_msg_new=0;
var leidos=0;

function iniciar(rol_id,titulo,desc,fecha,personas_id){
    var id_usuario=$('#inp_id_user').val();
    var array_usuario =personas_id.split(",");    
    var rol_user=$('#inp_rol_user').val();
    var array_rol =rol_id.split(",");
    var sino=false;//mensajes si es para usuario
    //ver si es para usuario especifico
    array_usuario.forEach(function(elemento, indice){//Indice: indice  Valor:  elemento
        //console.log('arrayUsuario->'+elemento+' act:'+id_usuario);
        if(elemento==id_usuario){
          alertify.success('<span class="icon-user-following" style="color:black; background:#d7f70c;padding:0.6em;border-radius:50%;"></span> NUEVO COMUNICADO PERSONAL');
            sino=true; 
         }
    });
    //ver si es para grupo perteneciente
    array_rol.forEach(function(elemento, indice){//Indice: indice  Valor:  elemento 
        //console.log('array_rol->'+elemento+' act:'+rol_user);
        if(elemento==rol_user){
          alertify.success('<span class="icon-people" style="color:#fff; background:#4cc8e0;padding:0.6em;border-radius:50%;"></span> NUEVO COMUNICADO GRUPAL');
          sino=true; 
         }
    });
    //el usuario esta en el array
    if(sino){//|| n_inicios==0){ 
     cc_msg_new=0;
    //console.log("se cargan las notificaciones");
    $.ajax({
        url: '?/s-notificaciones/consultasnotificaciones',
        type:'POST',
        data: {accion:'listar_notificaciones'},      
        dataType: 'JSON',
        success: function(resp){
            //console.log(resp);
           if(resp.length>0){               
            $('.notification-list').html('');
            for (var i = 0; i < resp.length; i++) {  
                $('.notification-list').prepend('<div class="list-group"> <a href="?/s-notificaciones/listar" class="list-group-item list-group-item-action active"> <div console.dir(obj);lass="notification-info"> <div class="notification-list-user-img"><img src="<?= imgs  ?>/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle my-1" width="25" ></div> <div class="notification-list-user-block"><span class="notification-list-user-name">'+resp[i]['nombre_evento']+'</span>'+resp[i]['descripcion']+' <div class="notification-date">'+resp[i]['fecha_registro']+'<span class="fa fa-check" style="float: right;"></span><span class="fa fa-check" style="float: right;"></span></div></div>     <div class="notification-list-user-block"> </div> </div>  </a>  </div>'); 
                 cc_msg_new++;//=resp.length; 
            }             
                indicator(); 
                Notification.requestPermission(function(permission){
                    var notification = new Notification(titulo,{
                        body:desc,
                        icon:"https://bower.io/img/bower-logo.png"
                     });
                     notification.onclick = function(){
                     alert('notificacion');
                      windows.open('?/s-notificaciones/listar');
                     };

                }); 
            }
        },
        error: function(e){
            //console.log('error de solicitud de notificacion:');
            console.log(e);
        }
     });               
    }else{
       $.ajax({
        url: '?/s-notificaciones/consultasnotificaciones',
        type:'POST',
        data: {accion:'listar_notificaciones'},      
        dataType: 'JSON',
        success: function(resp){
            //console.log(resp);
           if(resp.length>0){               
            $('.notification-list').html('');
            for (var i = 0; i < resp.length; i++) {  
                $('.notification-list').prepend('<div class="list-group"> <a href="?/s-notificaciones/listar" class="list-group-item list-group-item-action active"> <div console.dir(obj);lass="notification-info"> <div class="notification-list-user-img"><img src="<?= imgs  ?>/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle my-1" width="25" ></div> <div class="notification-list-user-block"><span class="notification-list-user-name">'+resp[i]['nombre_evento']+'</span>'+resp[i]['descripcion']+' <div class="notification-date">'+resp[i]['fecha_registro']+'<span class="fa fa-check" style="float: right;"></span><span class="fa fa-check" style="float: right;"></span></div></div>     <div class="notification-list-user-block"> </div> </div>  </a>  </div>'); 
                 
            }             
                // indicator(); 
                // Notification.requestPermission(function(permission){
                //     var notification = new Notification(titulo,{
                //         body:desc,
                //         icon:"https://bower.io/img/bower-logo.png"
                //      });
                //      notification.onclick = function(){
                //      alert('notificacion');
                //       windows.open('?/s-notificaciones/listar');
                //      };

                // }); 
            }
        },
        error: function(e){
            //console.log('error de solicitud de notificacion:');
            console.log(e);
        }
     });   
    }
 };
     
//click para leer las notificaciones
function  leermensajes(){ 
   //$('#cc_msg_new').val();
    //alert('leer- contador'+cc_msg_new);
    leidos=cc_msg_new;
    indicator(); 
   }
     
     
function indicator(){
    //alert('in-contador'+cc_msg_new);
    var verif=cc_msg_new-leidos;//18-0/19-18/
    // alert('leidos:'+leidos+' contador:'+cc_msg_new+' icono:'+verif);
     if(verif!=0){
       $('.indicator').addClass('indicator2');
       $('.indicator').find('b').text(verif);
       $('.indicator').css('background-color','#ef172c'); 

       }else{
       $('.indicator').find('b').text('');
       $('.indicator').removeClass('indicator2',''); 
       $('.indicator').css('background-color','transparent');
      }
}
</script>		
	</body>
</html>