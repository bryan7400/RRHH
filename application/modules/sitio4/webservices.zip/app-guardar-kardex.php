
<?php
/**
 * FunctionPHP - Framework Functional PHP
 * 
 * @package  FunctionPHP
 * @author   EDUCHECK (MARIBEL MARCO LUIS)
 */

// Define las cabeceras
header('Content-Type: application/json');

//Verifica la peticion post
if (is_post()) {

    // Verifica la existencia de datos
    if (isset($_POST['usuario']) && isset($_POST['contrasenia'])) {
        //Obtiene los datos
        $usuario = clear($_POST['usuario']);
        $contrasenia = clear($_POST['contrasenia']);
        //$id_gestion =clear($_POST['id_gestion']);
        $id_gestion = clear($_POST['id_gestion']);
        // Encripta la contraseña para compararla en la base de datos
        $usuario = md5($usuario);
        $contrasenia = encrypt($contrasenia);

        // Obtiene los datos del usuario
        $usuario = $db->select('gestion_id')->from('sys_users')->open_where()->where('md5(username)', $usuario)->or_where('md5(email)', $usuario)->close_where()->where(array('password' => $contrasenia, 'active' => 's'))->fetch_first();


        // Verifica la existencia del usuario 
        if ($usuario) {

            $tipo_kardex = $_POST['tipo_kardex'];

            if ($tipo_kardex == "btn_citacion") {

                $id_citacion = $_POST['id_citacion'];
                $motivo = $_POST['motivo_ci'];
                $fecha_envio = $fecha_actual;
                $fecha_asistencia = $_POST['fecha_ci'];
                $profesor_materia_id = $_POST['id_profesor_materia'];
                $id_estudiante = $_POST['id_estudiante'];
                $modo_calificacion_id = $_POST['modo_calificacion_id'];
                if (isset($id_citacion) && $id_citacion != '') {
                    //editar::::::::::::::::::::::::::::::::
                    $datcitacion = array(
                        'motivo' => $motivo,
                        'fecha_asistencia' => $fecha_asistencia,
                        'usuario_modificacion' =>  $_user['id_user'],
                        'fecha_modificacion' => date('Y-m-d H:i:s')
                    );
                    //$db->insert('arc_sanciones', $felicitacion);
                    $db->where('id_citacion', $id_citacion)->update('arc_citaciones', $datcitacion);
                    echo 3; //edit corrcetmnetr
                } else {
                    //crear:::::::::::::::::
                    $sql_inscripcion = $db->query("SELECT id_inscripcion, estudiante_id
        										FROM ins_inscripcion 
        										WHERE estudiante_id = $id_estudiante AND gestion_id = $id_gestion")->fetch_first();
                    $id_inscripcion = $sql_inscripcion['id_inscripcion'];

                    //var_dump($_POST);die;
                    /*$sql_archivo = $db->query("SELECT *
        								   FROM arc_archivo 
        								   WHERE inscripcion_id = $id_inscripcion")->fetch_first();
        		$valor = $sql_archivo['id_archivo'];*/
                    $sql_archivo = $db->query("SELECT *
        								   FROM arc_archivo 
        								   WHERE inscripcion_id = $id_inscripcion")->fetch_first();
                    $valor = $sql_archivo['id_archivo'];

                    if (isset($valor)) {
                        //Si existe el estudiante solo recuperamos el id para poder añadir su sancion

                        $citacion = array(
                            'asignacion_docente_id' => $profesor_materia_id,
                            'motivo' => $motivo,
                            'fecha_envio' => date('Y-m-d'),
                            'fecha_asistencia' => $fecha_asistencia,
                            'archivo_id' => $valor,
                            'estado' => 'A',
                            'usuario_registro' => $_user['id_user'],
                            'fecha_registro' => date('Y-m-d H:i:s'),
                            'usuario_modificacion' => '0',
                            'fecha_modificacion' => date('Y-m-d H:i:s'),
                            'modo_calificacion_id' => $modo_calificacion_id
                        );
                        $db->insert('arc_citaciones', $citacion);

                        if ($db->affected_rows) {
                            echo 1;
                        } else {
                            echo 2;
                        }
                    } else {
                        //Creamos el archivo para el estudiante
                        $archivo = array(
                            'inscripcion_id' => $id_inscripcion,
                            'estado' => 1
                        );
                        //$sqlArchivo = "INSERT INTO arc_archivo (inscripcion_id, estado) VALUES ('{$id_estudiante_ins}', '1');";			

                        $id_archivo = $db->insert('arc_archivo', $archivo);
                        //  var_dump($id_archivo);exit();

                        $citacion = array(
                            'asignacion_docente_id' => $profesor_materia_id,
                            'motivo' => $motivo,
                            'fecha_envio' => date('Y-m-d'),
                            'fecha_asistencia' => $fecha_asistencia, //$fecha_traer_tutor,
                            'archivo_id' => $id_archivo,
                            'estado' => 'A',
                            'usuario_registro' => $_user['id_user'],
                            'fecha_registro' => date('Y-m-d H:i:s'),
                            'usuario_modificacion' => '0',
                            'fecha_modificacion' => date('Y-m-d H:i:s'),
                            'modo_calificacion_id' => $modo_calificacion_id
                        );
                        $db->insert('arc_citaciones', $citacion);
                        if ($db->affected_rows) {
                            echo 1;
                        } else {
                            echo 2;
                        }
                    }
                } //fin crear
            }

            if ($tipo_kardex == "felicitacion") {

                $motivo = $_POST['motivo'];

                $id_felicitacion = $_POST['id_felicitacion'];
                $descripcion = $_POST['descripcion'];
                //$fecha_felicitacion = $_POST['fecha_felicitacion'];
                $profesor_materia_id = $_POST['id_profesor_materia'];
                $id_estudiante = $_POST['id_estudiante'];
                $modo_calificacion_id = $_POST['modo_calificacion_id'];
                $estado_curso = $_POST['tipo_extra'];

                if (isset($id_felicitacion) && $id_felicitacion != '') {
                    //editar::::::::::::::::::::::::::::::::
                    $datFelicitacion = array(
                        'motivo' => $motivo,
                        'descripcion' => $descripcion,
                        'usuario_modificacion' =>  $_user['id_user'],
                        'fecha_modificacion' => date('Y-m-d H:i:s')
                    );
                    //$db->insert('arc_sanciones', $felicitacion);
                    $db->where('id_felicitaciones', $id_felicitacion)->update('arc_felicitaciones', $datFelicitacion);
                    echo 3; //edit corrcetmnetr
                } else {
                    //crear:::::::::::::::::
                    //obtener id inscripcion, depende de si se inscribio en extracurricular o en curso normal
                    if ($estado_curso != 'E') {
                        //NORmAL
                        $sql_inscripcion = $db->query("SELECT id_inscripcion, estudiante_id
										FROM ins_inscripcion 
										WHERE estudiante_id = $id_estudiante and gestion_id=$id_gestion and estado='A'")->fetch_first(); // AND gestion_id = $id_gestion")->fetch_first();
                        //echo 'Normal';
                    } else {
                        //extrayemos el id inscripcion EXTRACURRCULAR
                        $sql_inscripcion = $db->query("SELECT id_curso_inscripcion as id_inscripcion, estudiante_id
									FROM ext_curso_inscripcion 
									WHERE estudiante_id = $id_estudiante and gestion_id=$id_gestion and estado='A'")->fetch_first();
                        //echo 'Extra';
                    }

                    if ($sql_inscripcion) {

                        $id_inscripcion = $sql_inscripcion['id_inscripcion'];
                        //Buscamos el id_archivo del estudiante
                        $sql_archivo = $db->query("SELECT *
								   FROM arc_archivo 
								   WHERE inscripcion_id = $id_inscripcion")->fetch_first();
                        $valor = $sql_archivo['id_archivo'];
                        //var_dump($valor);die;

                        //Preguntamos si existe el archivo 1 si existiese y 0 no existe
                        if (isset($valor)) {
                            //Si existe el estudiante solo recuperamos el id para poder añadir su sancion

                            $felicitacion = array(
                                'asignacion_docente_id' => $profesor_materia_id,
                                'motivo' => $motivo,
                                'descripcion' => $descripcion,
                                'fecha_felicitacion' => date('Y-m-d'),
                                'archivo_id' => $valor,
                                'estado' => 'A',
                                'usuario_registro' => $_user['id_user'],
                                'fecha_registro' => date('Y-m-d H:i:s'),
                                'usuario_modificacion' => '0',
                                'fecha_modificacion' => date('Y-m-d H:i:s'),
                                'modo_calificacion_id' => $modo_calificacion_id
                            );
                            $db->insert('arc_felicitaciones', $felicitacion);

                            if ($db->affected_rows) {
                                echo 1;
                            } else {
                                echo 2;
                            }
                        } else {
                            //Creamos el archivo para el estudiante
                            $archivo = array(
                                'inscripcion_id' => $id_inscripcion,
                                'estado' => 1,
                                'estado_curso' => $estado_curso
                            );
                            //$sqlArchivo = "INSERT INTO arc_archivo (inscripcion_id, estado) VALUES ('{$id_estudiante_ins}', '1');";			

                            $id_archivo = $db->insert('arc_archivo', $archivo);

                            $felicitacion = array(
                                'asignacion_docente_id' => $profesor_materia_id,
                                'motivo' => $motivo,
                                'descripcion' => $descripcion,
                                'fecha_felicitacion' => date('Y-m-d'),
                                'archivo_id' => $id_archivo,
                                'estado' => 'A',
                                'usuario_registro' => $_user['id_user'],
                                'fecha_registro' => date('Y-m-d H:i:s'),
                                'usuario_modificacion' => '0',
                                'fecha_modificacion' => date('Y-m-d H:i:s'),
                                'modo_calificacion_id' => $modo_calificacion_id
                            );
                            $db->insert('arc_felicitaciones', $felicitacion);

                            if ($db->affected_rows) {
                                echo 1;
                            } else {
                                echo 2;
                            }
                        }
                    } else {
                        echo 11;
                    }
                } //fin crear::::::
            }

            if ($tipo_kadex == "sancion") {
                $id_sancion = $_POST['id_sancion'];
                $motivo = $_POST['motivo'];
                $fecha_sancion = $fecha_actual;
                $dias_suspencion = $_POST['dias'];
                $traer_tutor = $_POST['traertutor'];
                $fecha_traer_tutor = $_POST['fecha_asistir'];
                $modo_calificacion_id = $_POST['modo_calificacion_id'];
                $asistio_tutor = "0";
                $fecha_asistio_tutor = $fecha_actual;
                if (isset($id_sancion) && $id_sancion != '') {
                    //editar::::::::::::::::::::::::::::::::
                    //editar::::::::::::::::::::::::::::::::
                    $sancion = array(         //'asignacion_docente_id'=> $profesor_materia_id,
                        'motivo' => $motivo,
                        //'fecha_sancion'=> date('Y-m-d'),
                        'dias_suspencion' => $dias_suspencion,
                        'traer_tutor' => $traer_tutor,
                        'fecha_traer_tutor' => $fecha_traer_tutor,
                        //'asistio_tutor'=> $asistio_tutor,
                        //'fecha_asistio_tutor'=> $fecha_asistio_tutor,
                        //'archivo_id' => $id_archivo,
                        //'estado'=> 'A',
                        //'usuario_registro'=> $_user['id_user'],
                        //'fecha_registro'=> date('Y-m-d H:i:s'),
                        'usuario_modificacion' =>  $_user['id_user'],
                        'fecha_modificacion' => date('Y-m-d H:i:s')
                    );
                    //$db->insert('arc_sanciones', $felicitacion);
                    $db->where('id_sancion', $id_sancion)->update('arc_sanciones', $sancion);
                    echo 3; //edit corrcetmnetr
                } else {
                    //:::::::::::::::NEW:::::::::::::::::::::::::
                    $profesor_materia_id = $_POST['id_profesor_materia'];
                    $id_estudiante = $_POST['id_estudiante'];

                    $sql_inscripcion = $db->query("SELECT id_inscripcion, estudiante_id
                                            FROM ins_inscripcion 
                                            WHERE estudiante_id = $id_estudiante AND gestion_id = $id_gestion")->fetch_first();
                    $id_inscripcion = $sql_inscripcion['id_inscripcion'];

                    //var_dump($_POST);die;
                    $sql_archivo = $db->query("SELECT *
                                       FROM arc_archivo 
                                       WHERE inscripcion_id = $id_inscripcion")->fetch_first();
                    $valor = $sql_archivo['id_archivo'];

                    if (isset($valor)) {
                        //Si existe el estudiante solo recuperamos el id para poder añadir su sancion

                        $sancion = array(
                            'asignacion_docente_id' => $profesor_materia_id,
                            'motivo' => $motivo,
                            'fecha_sancion' => date('Y-m-d'),
                            'dias_suspencion' => $dias_suspencion,
                            'traer_tutor' => $traer_tutor,
                            'fecha_traer_tutor' => $fecha_traer_tutor,
                            'asistio_tutor' => $asistio_tutor,
                            'fecha_asistio_tutor' => $fecha_asistio_tutor,
                            'archivo_id' => $valor,
                            'estado' => 'A',
                            'usuario_registro' => $_user['id_user'],
                            'fecha_registro' => date('Y-m-d H:i:s'),
                            'usuario_modificacion' => '0',
                            'fecha_modificacion' => date('Y-m-d H:i:s'),
                            'modo_calificacion_id' => $modo_calificacion_id
                        );
                        $db->insert('arc_sanciones', $sancion);

                        if ($db->affected_rows) {
                            echo 1;
                        } else {
                            echo 2;
                        }
                    } else {
                        //Creamos el archivo para el estudiante
                        $archivo = array(
                            'inscripcion_id' => $id_inscripcion,
                            'estado' => 1
                        );
                        //$sqlArchivo = "INSERT INTO arc_archivo (inscripcion_id, estado) VALUES ('{$id_estudiante_ins}', '1');";			

                        $id_archivo = $db->insert('arc_archivo', $archivo);

                        $sancion = array(
                            'asignacion_docente_id' => $profesor_materia_id,
                            'motivo' => $motivo,
                            'fecha_sancion' => date('Y-m-d'),
                            'dias_suspecion' => $dias_suspencion,
                            'traer_tutor' => $traer_tutor,
                            'fecha_traer_tutor' => $fecha_traer_tutor,
                            'asistio_tutor' => $asistio_tutor,
                            'fecha_asistio_tutor' => $fecha_asistio_tutor,
                            'archivo_id' => $id_archivo,
                            'estado' => 'A',
                            'usuario_registro' => $_user['id_user'],
                            'fecha_registro' => date('Y-m-d H:i:s'),
                            'usuario_modificacion' => '0',
                            'fecha_modificacion' => date('Y-m-d H:i:s'),
                            'modo_calificacion_id' => $modo_calificacion_id
                        );
                        $db->insert('arc_sanciones', $felicitacion);

                        if ($db->affected_rows) {
                            echo 1;
                        } else {
                            echo 2;
                        }
                    }
                }
            }

            $modo_calificacion_id = $_POST['modo_calificacion_id'];
            $estudiante_id = $_POST['estudiante_id'];
            $asistencia = $_POST['asistencia'];
            echo json_encode($respuesta);
        } else {
            // Devuelve los resultados
            echo json_encode(array('estado' => 'n'));
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'u'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'p'));
}

?>