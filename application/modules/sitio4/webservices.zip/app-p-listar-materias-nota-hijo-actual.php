<?php
/**
 * FunctionPHP - Framework Functional PHP
 * 
 * @package  FunctionPHP
 * @author   EDUCHECK (MARIBEL MARCO LUIS)
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
 if (is_post()) {
    
	// Verifica la existencia de datos
	if (isset($_POST['usuario']) && isset($_POST['contrasenia'])) {
		//Obtiene los datos
		$usuario 		  = clear($_POST['usuario']);
        $contrasenia 	  = clear($_POST['contrasenia']);
		$id_aula_paralelo = clear($_POST['id_aula_paralelo']);
		$id_estudiante    = clear($_POST['id_estudiante']);
		$id_gestion       = clear($_POST['id_gestion']);
		
		$id_estudiante_elegido    = clear($_POST['id_estudiante']);
        
        $hoy = date('Y-m-d'); 
        $sql_modo_calificacion = "SELECT * FROM cal_modo_calificacion WHERE gestion_id ='$id_gestion' and fecha_inicio <= '$hoy' and fecha_final >= '$hoy' AND estado = 'A'";
		$modos_calificacion = $db->query($sql_modo_calificacion)->fetch_first();
		
		$id_modo_calificacion = ((isset($modos_calificacion['id_modo_calificacion'])?$modos_calificacion['id_modo_calificacion']:"0"));
        
		$usuario    = md5($usuario);
		$contrasenia = encrypt($contrasenia);
		
		//Busacamos las materias regulares que tiene el estudiantes
		$sql_materia_regular = "SELECT pad.id_asignacion_docente , pm.id_materia, pm.cod_materia, pm.nombre_materia, pm.icono_materia, pm.orden, pm.imagen_materia, pm.color_materia, CONCAT(sp.nombres,' ',sp.primer_apellido,' ',sp.segundo_apellido ) AS nombre_docente
                                            FROM pro_asignacion_docente AS pad
                                            INNER JOIN pro_materia AS pm ON pm.id_materia = pad.materia_id
                                            INNER JOIN per_asignaciones AS pa ON pa.id_asignacion = pad.asignacion_id
                                            INNER JOIN sys_persona AS sp ON sp.id_persona = pa.persona_id
                                            WHERE pad.aula_paralelo_id = $id_aula_paralelo AND	pad.gestion_id = $id_gestion AND pad.estado_docente = 'A' AND pm.estado = 'A' AND pm.campo_area = 'NO'
                                            ORDER BY pm.orden ASC";
		
		$res_materia_regular = $db->query($sql_materia_regular)->fetch();
		
		//Buscamos las area a las que esta inscrito
		$sql_extracurricular = "SELECT eca.id_curso_asignacion, ec.id_curso, ec.categoria_id, ec.nombre_curso, ec.icono_curso,ec.imagen_curso
                                    FROM ext_curso_inscripcion AS eci
                                    INNER JOIN ext_curso_asignacion AS eca ON eca.id_curso_asignacion = eci.curso_asignacion_id
                                    INNER JOIN ext_curso AS ec ON ec.id_curso = eca.curso_id
                                    WHERE eci.estado = 'A' AND eci.gestion_id = $id_gestion AND eca.estado = 'A' AND eca.gestion_id = $id_gestion AND estudiante_id = $id_estudiante";
        $res_extracurricular = $db->query($sql_extracurricular)->fetch();
        
        
        //Buscamos a las areas que esta inscrito
        //$sql_area = "SELECT pad.id_asignacion_docente , pm.id_materia, pm.cod_materia, pm.nombre_materia, pm.icono_materia, pm.orden, pm.imagen_materia, pm.color_materia
        $sql_area = "SELECT *
                        FROM ins_inscripcion AS ii
                        WHERE ii.gestion_id = $id_gestion AND ii.estado = 'A' AND ii.area != '' AND ii.estado_inscripcion = 'INSCRITO' AND ii.estudiante_id = $id_estudiante";
        $res_area = $db->query($sql_area)->fetch();
		
		// Ya verificado todos los demas cursos
		// Extraemos las areas de calificacion
		$sql_areas_calificacion = "SELECT *
		                            FROM cal_area_calificacion as cac
		                            WHERE cac.estado = 'A' AND cac.gestion_id = $id_gestion
		                            ORDER BY orden ASC";
		$res_areas_calificacion = $db->query($sql_areas_calificacion)->fetch();
		//Armamos el array de Areas de calificacion con su ponderado
    		$i = 1;
    		foreach ($res_areas_calificacion as $key => $value) {
    			$aAreaCalificacion[$i]["id"]		= $value['id_area_calificacion'];
    			$aAreaCalificacion[$i]["nombre"]	= $value['descripcion'];
    			$aAreaCalificacion[$i]["ponderado"]	= $value['ponderado'];
    			$i++;								
    		}			
		//fin areas de calificacion	
			
		
		// Obtiene los datos del usuario
		$usuario = $db->select('id_user')->from('sys_users')->open_where()->where('md5(username)', $usuario)->or_where('md5(email)', $usuario)->close_where()->where(array('password' => $contrasenia, 'active' => 's'))->fetch_first();
		
		// Verifica la existencia del usuario 
		if ($usuario) {

			
			$aMaterias_hijo = array();
			$iMaterias_hijo = 0;
			foreach ($res_materia_regular as $key_materias => $value_materias) {
				
				//Obtenemos el id de la materia
				$id_asignacion_docente = $value_materias['id_asignacion_docente'];				 
			

				//Obtenemos todas las notas de las areas de calificacion y segun modo calificacion
				
				$sql_actividades = "SELECT taca.*, cac.*
                                        FROM tem_asesor_curso_actividad AS taca
                                        INNER JOIN cal_area_calificacion AS cac ON cac.id_area_calificacion = taca.area_calificacion_id
                                        WHERE taca.asignacion_docente_id = $id_asignacion_docente AND taca.modo_calificacion_id = 1 AND taca.presentar_actividad = 'SI' AND taca.estado_actividad = 'A'
                                        ORDER	BY cac.orden ASC";
				$res_actividades = $db->query($sql_actividades)->fetch();

				//Consultamos los estudiantes de un aula y paralelo
				$respuesta_estudiante = $db->query("SELECT ii.aula_paralelo_id AS id_aula_paralelo, ie.id_estudiante, p.nombres, p.primer_apellido, p.segundo_apellido, ii.codigo_inscripcion
                                                        FROM ins_inscripcion AS ii
                                                        INNER JOIN ins_estudiante AS ie ON ie.id_estudiante = ii.estudiante_id
                                                        INNER JOIN sys_persona AS p ON p.id_persona = ie.persona_id
                                                        WHERE ii.estado_inscripcion = 'INSCRITO' AND ii.estado = 'A'  AND ii.gestion_id = $id_gestion AND ii.aula_paralelo_id = $id_aula_paralelo")->fetch();			
				//var_dump($respuesta_estudiante); exit;

				$e = 1;
				$aEstudiantes = array();
				foreach ($respuesta_estudiante as $key => $value_estudiante) {
					$aEstudiantes[$e]["id_aula_paralelo"]  = $value_estudiante['id_aula_paralelo'];
					$aEstudiantes[$e]["id_estudiante"]     = $value_estudiante['id_estudiante'];
					$aEstudiantes[$e]["nombre_estudiante"] = $value_estudiante['primer_apellido']." ".$value_estudiante['segundo_apellido']." ".$value_estudiante['nombres'];
					$e++;
				}
				//Fin Terminar el armado del array estudiante

				//var_dump($aEstudiantes); exit;

				//Armamos el array para las notas de los estudiantes y sus actividades
				$aNotasEstudiante = array();
				
				$cac = 1;
				foreach ($aEstudiantes as $key => $value) {
					//$value['nombre_estudiante']);
					$id_estudiante = $value['id_estudiante'];
					$id_aula_paralelo = $value['id_aula_paralelo'];
							
					foreach ($aAreaCalificacion as $i => $valor) {
						$area_calificacion_id = $aAreaCalificacion[$i]['id'];
											
						$resSql = "SELECT taca.*, cac.*
                                    FROM tem_asesor_curso_actividad AS taca
                                    INNER JOIN cal_area_calificacion AS cac ON cac.id_area_calificacion = taca.area_calificacion_id
                                    WHERE taca.asignacion_docente_id = $id_asignacion_docente AND taca.modo_calificacion_id = $id_modo_calificacion AND taca.area_calificacion_id = $area_calificacion_id AND taca.presentar_actividad = 'SI' AND taca.estado_actividad = 'A'
                                    ORDER	BY cac.orden ASC";					

						//var_dump($resSql);
						$resConsulta = $db->query($resSql)->fetch();
						
						//var_dump($resConsulta);
						foreach ($resConsulta as $key => $fila_actividad) {
							//Preguntamos la nota que le corresponda al estudiante en la actividad correspondiente
							$id_asesor_curso_actividad = $fila_actividad['id_asesor_curso_actividad'];	
							$res_estudiante_actividad = $db->query("SELECT * FROM tem_estudiante_curso_actividad AS teca WHERE teca.asesor_curso_actividad_id = $id_asesor_curso_actividad AND teca.estudiante_id = $id_estudiante;")->fetch_first();
							
							if($res_estudiante_actividad != null){
								$aNotasEstudiante [$id_estudiante][$aAreaCalificacion[$i]['nombre']."/".$aAreaCalificacion[$i]['ponderado']][$fila_actividad['id_asesor_curso_actividad']]=$res_estudiante_actividad['nota'] ;
							}else{
								$aNotasEstudiante [$id_estudiante][$aAreaCalificacion[$i]['nombre']."/".$aAreaCalificacion[$i]['ponderado']][$fila_actividad['id_asesor_curso_actividad']]="0" ;
							}
							//Armamos las cabeceras para un mejor detalle
							//$aCabeceraActividades [$aAreaCalificacion[$i]['nombre']."/".$aAreaCalificacion[$i]['ponderado']][$fila_actividad['id_actividad_materia_modo_area']]= [$fila_actividad['nombre_actividad']];	
						}                					
					}							
				}
				//Fin de armar un array de las notas de los estudiantes por cada actividad 
				
				//var_dump($aNotasEstudiante);				

				//Llenamos las filas de tal manera que se liste los estudiantes y se muestres las notas por cada actividad
				$respuesta_estudiante = $db->query("SELECT ii.aula_paralelo_id AS id_aula_paralelo, ie.id_estudiante, p.nombres, p.primer_apellido, p.segundo_apellido, ii.codigo_inscripcion
                                                        FROM ins_inscripcion AS ii
                                                        INNER JOIN ins_estudiante AS ie ON ie.id_estudiante = ii.estudiante_id
                                                        INNER JOIN sys_persona AS p ON p.id_persona = ie.persona_id
                                                        WHERE ii.estado_inscripcion = 'INSCRITO' AND ii.estado = 'A'  AND ii.gestion_id = $id_gestion AND ii.aula_paralelo_id = $id_aula_paralelo")->fetch();
				//var_dump($respuesta_estudiante); exit;
				//Variables para el promedio del curso de la materia 
				
				//preguntamos que el array no este vacio
				if(!empty($aNotasEstudiante)){
					$nota_materia_estudiante = 0;
					$nota_materia_promedio   = 0;
					$nota_estudiante_materia_promedio   = 0;     
													
					foreach ($respuesta_estudiante as $key => $fila_estudiante){
					
						$suma_areas_calificacion_est = 0;					
						$id_estudiante = $fila_estudiante['id_estudiante'];
									
						//colocar las notas por estudiante por bimestre			
						foreach ($aNotasEstudiante[$id_estudiante] as $key => $value) {
							$ponderado = explode("/",$key);
							$ponderado_area = $ponderado[1];
							$suma = 0;
							$nro = sizeof($value);
														
							foreach ($value as $k => $val) {
								$suma +=$val;
							}
							
							$suma_areas_calificacion_est += round(round($suma/$nro)*$ponderado_area/100);
						
						}
						
						if($id_estudiante_elegido == $id_estudiante){
							//Aca encontramos la nota del estudiante
							$nota_materia_estudiante = $suma_areas_calificacion_est;
						}
						//Aca sumamos todas las notas de los estudiantes para luego promediarlos
						$nota_estudiante_materia_promedio = $nota_estudiante_materia_promedio + $suma_areas_calificacion_est;												
					}
					//Aca sacamos el prmedio del curso en la materia
					$nota_materia_promedio = round($nota_estudiante_materia_promedio/sizeof($respuesta_estudiante));
					
					//Armamos el objeto estudiante materia nota
					$aMaterias_hijo [$iMaterias_hijo]["id_asignacion_docente"]= $value_materias['id_asignacion_docente'];
					$aMaterias_hijo [$iMaterias_hijo]["tipo_curso"]= "N";
					$aMaterias_hijo [$iMaterias_hijo]["nombres_docente"]= $value_materias['nombre_docente'];
					$aMaterias_hijo [$iMaterias_hijo]["nombre_materia"]= $value_materias['nombre_materia'];
					$aMaterias_hijo [$iMaterias_hijo]["nota_materia_estudiante"]= $nota_materia_estudiante;
					$aMaterias_hijo [$iMaterias_hijo]["nota_materia_promedio"]= $nota_materia_promedio;
					
					//var_dump("Nota > ".$nota_materia_promedio);
				}else{					
					//Aca entra solo por que no exite notas registradas sobre las actividades
					//Armamos el objeto estudiante materia nota
					$aMaterias_hijo [$iMaterias_hijo]["id_asignacion_docente"]= $value_materias['id_asignacion_docente'];
					$aMaterias_hijo [$iMaterias_hijo]["tipo_curso"]= "N";
					$aMaterias_hijo [$iMaterias_hijo]["nombres_docente"]= $value_materias['nombre_docente'];
					$aMaterias_hijo [$iMaterias_hijo]["nombre_materia"]= $value_materias['nombre_materia'];
					$aMaterias_hijo [$iMaterias_hijo]["nota_materia_estudiante"]= 0;
					$aMaterias_hijo [$iMaterias_hijo]["nota_materia_promedio"]= 0;	
				}
				$iMaterias_hijo++;	
			}//fin de foreach de las materias por hijo

			// Instancia el objeto que devolvera la web service			
			$respuesta = array(
				'estado' => 's',
				'materias_hijo' => $aMaterias_hijo					
			);

			// Devuelve los resultados
			echo json_encode($respuesta);
		} else {
			// Devuelve los resultados
			echo json_encode(array('estado' => 'n'));
		}
	} else {
	// 	// Devuelve los resultados
	   echo json_encode(array('estado' => 'n usuario'));
	}
} else {
// 	// Devuelve los resultados
    echo json_encode(array('estado' => 'npost'));
}
