<?php

/**
 * FunctionPHP - Framework Functional PHP
 * 
 * @package  WEB SERVICES
 * @author  MARCO ANTONIO QUINO CHOQUETA
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
	// Verifica la existencia de datos
	if (isset($_POST['usuario']) && isset($_POST['contrasenia'])) {
		// Obtiene los datos
		$usuario = clear($_POST['usuario']);
		$contrasenia = clear($_POST['contrasenia']);
        $usuario = md5($usuario);
		$contrasenia = encrypt($contrasenia);
 
		$id_gestion = clear($_POST['id_gestion']);
        
        $usuario = $db->select('persona_id,id_user, username, email, avatar, rol_id, visible')->from('sys_users')->open_where()->where('md5(username)', $usuario)->or_where('md5(email)', $usuario)->close_where()->where(array('password' => $contrasenia, 'active' => 's'))->fetch_first();
		// Verifica la existencia del usuario
		if ($usuario) {
		// Obtiene los datos:::::::::::::::::::::::::::::::::::::::
            
        $id_asignacion_docente = $_POST['id_asignacion_docente'];//id_asignacion_docente
        $id_bimestre = $_POST['id_bimestre'];
            
        //SELECT (SELECT obs.id_estudiante_modo_observacion FROM cal_estudiante_modo_observacion obs WHERE obs.estudiante_id=e.`id_estudiante`  AND obs.estado_curso='N'  AND obs.modo_calificacion_id=$id_bimestre  LIMIT 1)AS id_estudiante_modo_observacion,(SELECT obs.valoracion_cualitativa FROM cal_estudiante_modo_observacion obs WHERE obs.estudiante_id=e.`id_estudiante`  AND obs.estado_curso='N' AND obs.modo_calificacion_id=$id_bimestre  LIMIT 1)AS valoracion_cualitativa,
            
        $estudiantes_cursos = $db->query("SELECT  z.estudiante_id, p.id_persona,p.nombres,p.primer_apellido,p.segundo_apellido,p.tipo_documento,p.numero_documento,p.complemento,p.expedido,p.genero,p.fecha_nacimiento,p.foto
        
         FROM ins_inscripcion z 
            INNER JOIN ins_gestion g ON z.gestion_id=g.id_gestion  
            INNER JOIN ins_estudiante e ON z.estudiante_id=e.id_estudiante
            INNER JOIN sys_persona p ON e.persona_id=p.id_persona  
            INNER JOIN ins_aula_paralelo ap ON ap.id_aula_paralelo=z.aula_paralelo_id  
            INNER JOIN pro_asignacion_docente apam ON apam.aula_paralelo_id=ap.id_aula_paralelo
	    
    
        WHERE z.gestion_id=$id_gestion
	AND  apam.`id_asignacion_docente`=$id_asignacion_docente
            AND z.estado='A' 
            AND g.estado='A'
            AND ap.estado='A'
           

           ORDER BY   p.primer_apellido ASC,  p.segundo_apellido ASC")->fetch();
            
        /*  INNER JOIN ins_aula au ON au.id_aula=ap.aula_id  
            INNER JOIN ins_paralelo pa ON pa.id_paralelo=ap.paralelo_id
            INNER JOIN ins_turno tu ON tu.id_turno=ap.turno_id
            INNER JOIN ins_nivel_academico ni ON ni.id_nivel_academico=au.nivel_academico_id
            INNER JOIN ins_tipo_estudiante te ON te.id_tipo_estudiante=z.tipo_estudiante_id
             AND au.estado='A'
            AND ni.estado='A' 
            AND pa.estado_paralelo='A'
            */
            
            
            
            
            
        /*$estudiantes_cursos = $db->query("SELECT (SELECT obs.id_estudiante_modo_observacion FROM cal_estudiante_modo_observacion obs WHERE obs.estudiante_id=e.`id_estudiante` AND obs.estudiante_id=e.`id_estudiante`  AND obs.modo_calificacion_id=$id_bimestre  LIMIT 1)AS id_estudiante_modo_observacion,(SELECT obs.valoracion_cualitativa FROM cal_estudiante_modo_observacion obs WHERE obs.estudiante_id=e.`id_estudiante`  AND obs.modo_calificacion_id=$id_bimestre  LIMIT 1)AS valoracion_cualitativa,z.estudiante_id, p.*  
         FROM ins_inscripcion z 
            INNER JOIN ins_gestion g ON z.gestion_id=g.id_gestion  
            INNER JOIN ins_estudiante e ON z.estudiante_id=e.id_estudiante
            INNER JOIN sys_persona p ON e.persona_id=p.id_persona  
            INNER JOIN ins_aula_paralelo ap ON ap.id_aula_paralelo=z.aula_paralelo_id 
            
	    INNER JOIN int_aula_paralelo_asignacion_materia apam ON apam.`aula_paralelo_id`=ap.`id_aula_paralelo`
	    
            INNER JOIN ins_aula au ON au.id_aula=ap.aula_id  
            INNER JOIN ins_paralelo pa ON pa.id_paralelo=ap.paralelo_id
            INNER JOIN ins_turno tu ON tu.id_turno=ap.turno_id
            INNER JOIN ins_nivel_academico ni ON ni.id_nivel_academico=au.nivel_academico_id
            INNER JOIN ins_tipo_estudiante te ON te.id_tipo_estudiante=z.tipo_estudiante_id 
        WHERE z.gestion_id=$id_gestion  
	AND  apam.`id_aula_paralelo_asignacion_materia`=$id_aula_asignacion
            AND z.estado='A' 
            AND g.estado='A'
            AND ap.estado='A'
            AND pa.estado_paralelo='A'
            AND au.estado='A'
            AND ni.estado='A'
            AND apam.`estado`='A'

           ORDER BY   p.primer_apellido ASC,  p.segundo_apellido ASC")->fetch();*/
        
 
         echo json_encode(array('estado' => 's', 'estudiantes' => $estudiantes_cursos)); 
            //respuestas :::::::::::::::::::::::::::
          //   echo json_encode($respuesta);
		} else {
			// Devuelve los resultados
			echo json_encode(array('estado' => 'no tiene usuario asignado'));
		}
		} else {
		// Devuelve los resultados
		echo json_encode(array('estado' => 'no hay datos'));
	}
} else {
	// Devuelve los resultados
	echo json_encode(array('estado' => 'n'));
}

?>