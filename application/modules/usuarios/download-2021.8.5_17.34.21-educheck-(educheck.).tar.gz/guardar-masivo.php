<?php
 
/**
 * FunctionPHP - Framework Functional PHP 
 * 
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */
//var_dump($_POST);exit();

// Verifica la peticion post
if (is_post()) {

	// Verifica la cadena csrf
	if (isset($_POST[get_csrf()])) {

		// Verifica la existencia de datos
		if (isset($_POST['rol_id']) && isset($_POST['accion_usuario']) && isset($_POST['tipo_contrasenia'])) {
 
			// Obtiene los datos
			$rol_id 			= clear($_POST['rol_id']);
            $passwordg 			= $_POST['password'];
            $accion_usuario 	= clear($_POST['accion_usuario']);
            $tipo_contrasenia 	= clear($_POST['tipo_contrasenia']);
            $gestion_id 		= $_gestion['id_gestion'];
        
        //var_dump($gestion_id);exit();

            
            
            if($rol_id == 6 && $accion_usuario == 'C' && $tipo_contrasenia == 'CG'){ // CREAR Y PROGRAMADO
				// $familiar_sql = "SELECT p.*, i.gestion_id
				// FROM ins_estudiante_familiar ef
				// INNER JOIN ins_familiar f ON ef.familiar_id = f.id_familiar
				// INNER JOIN sys_persona p ON f.persona_id = p.id_persona
				// INNER JOIN ins_inscripcion i ON ef.estudiante_id = i.estudiante_id
				// WHERE i.gestion_id = $gestion_id";
				$familiar_sql ="SELECT p.*,u.*, i.gestion_id, IFNULL(u.id_user,0)id_usuario, IFNULL(u.rol_id,0)id_rol_usuario
				FROM ins_estudiante_familiar ef
                INNER JOIN ins_inscripcion i ON ef.estudiante_id = i.estudiante_id
                INNER JOIN ins_familiar f ON ef.familiar_id = f.id_familiar
                INNER JOIN sys_persona p ON f.persona_id = p.id_persona
                LEFT JOIN sys_users u ON p.id_persona = u.persona_id
                WHERE i.gestion_id = $gestion_id
                AND i.estado = 'A'
                AND i.estado_inscripcion != 'RETIRADO'
                AND i.estado_inscripcion != 'BAJA'
                GROUP BY f.id_familiar";
            	$familiar=$db->query($familiar_sql)->fetch();

                //var_dump($familiar);exit();

				if($familiar){

					foreach ($familiar as $value) {

	                    //////////////////////////////////////////////////////////////////////////
	                    $findt = array('Á','É','Í','Ó','Ú','Ñ','ñ','á','é','í','ó','ú');
						$replt = array('A','E','I','O','U','N','N','A','E','I','O','U');
	                    $nuevo_nombre_tutor = explode(" ", $value['nombres']);
	                    $username_nombre_tutor 	= $nuevo_nombre_tutor[0];

						$username_nombre_tutor  = str_replace($findt, $replt, $username_nombre_tutor);
						$paterno_tutor    = str_replace($findt, $replt, $value['primer_apellido']);
						$materno_tutor    = str_replace($findt, $replt, $value['segundo_apellido']);

	                    //////////////////////////////////////////////////////////////////////////
	                    if($paterno_tutor!=''){
	                       $username_apellido_tutor = clear($paterno_tutor); 
	                    }else{
	                       $username_apellido_tutor = clear($materno_tutor); 
	                    }

	                    if($value['numero_documento']){
	                    	//var_dump($value['numero_documento'].'el tutor cuenta con CI para generar su contraseña');
	                        $password_tutor = clear($value['numero_documento']);
	                        // }else if($fecha_php_tutor!=''){
	                        // $password_tutor = $fecha_php_tutor;
	                        // var_dump($ci_tutor.'fecha_php_tutor');
	                    }else{

	                        $password_tutor = strtoupper('T'.$username_nombre_tutor.$username_apellido_tutor);
	                        //var_dump($password_tutor.'El tutor no tiene CI su contraseña es por defecto el TUSERNAME');
	                    }


						// Instancia el usuario
						$usuario_tutores = array(
							'username'	=> strtoupper('T'.$username_nombre_tutor.'.'.$username_apellido_tutor),
							'password' 	=> encrypt($password_tutor),
							'email' 	=> clear(strtolower($value['email'])),
							'active' 	=> 's',
							'visible' 	=> 's',
							'rol_id' 	=> 6,
							'persona_id'=> $value['id_persona'],
							'gestion_id'=> $gestion_id,																			
							'avatar' 	=> '',
							'login_at' 	=> '0000-00-00 00:00:00',
							'logout_at' => '0000-00-00 00:00:00',
						);
						//var_dump($usuario);
                        if($value['id_usuario'] >0 && $value['id_rol_usuario'] == 6){
                        	// Modifica el usuario
						    $db->where('id_user', $value['id_usuario'])->update('sys_users', $usuario_tutores);
                        }else{
                        	// Crea el usuario
						    $id_usuario_tutor = $db->insert('sys_users', $usuario_tutores);
                        }
						
					}
		           
                    redirect('?/usuarios/listar');
                
		        }

            }elseif($rol_id == 6 && $accion_usuario == 'A' && $tipo_contrasenia == 'CG'){
               
                $familiar_sql = "SELECT p.*,u.*, i.gestion_id
				FROM ins_estudiante_familiar ef
				INNER JOIN ins_familiar f ON ef.familiar_id = f.id_familiar
				INNER JOIN sys_persona p ON f.persona_id = p.id_persona
				inner join sys_users u on p.id_persona = u.persona_id
				INNER JOIN ins_inscripcion i ON ef.estudiante_id = i.estudiante_id
				WHERE i.gestion_id = $gestion_id
				and u.rol_id = 6 ";
            	$familiar=$db->query($familiar_sql)->fetch();

                var_dump($familiar);exit();

				if($familiar){

					foreach ($familiar as $value) {

	                    //////////////////////////////////////////////////////////////////////////
	                    $findt = array('Á','É','Í','Ó','Ú','Ñ','ñ','á','é','í','ó','ú');
						$replt = array('A','E','I','O','U','N','N','A','E','I','O','U');
	                    $nuevo_nombre_tutor = explode(" ", $value['nombres']);
	                    $username_nombre_tutor 	= $nuevo_nombre_tutor[0];

						$username_nombre_tutor  = str_replace($findt, $replt, $username_nombre_tutor);
						$paterno_tutor    = str_replace($findt, $replt, $value['primer_apellido']);
						$materno_tutor    = str_replace($findt, $replt, $value['segundo_apellido']);

	                    //////////////////////////////////////////////////////////////////////////
	                    if($paterno_tutor!=''){
	                       $username_apellido_tutor = clear($paterno_tutor); 
	                    }else{
	                       $username_apellido_tutor = clear($materno_tutor); 
	                    }

	                    if($value['numero_documento']){
	                    	//var_dump($value['numero_documento'].'el tutor cuenta con CI para generar su contraseña');
	                        $password_tutor = clear($value['numero_documento']);
	                        // }else if($fecha_php_tutor!=''){
	                        // $password_tutor = $fecha_php_tutor;
	                        // var_dump($ci_tutor.'fecha_php_tutor');
	                    }else{

	                        $password_tutor = strtoupper('T'.$username_nombre_tutor.$username_apellido_tutor);
	                        //var_dump($password_tutor.'El tutor no tiene CI su contraseña es por defecto el TUSERNAME');
	                    }


						// Instancia el usuario
						$usuario_tutores = array(
							'username'	=> strtoupper('T'.$username_nombre_tutor.'.'.$username_apellido_tutor),
							'password' 	=> encrypt($password_tutor),
							'email' 	=> clear(strtolower($value['email'])),
							'rol_id' 	=> 6,
							'persona_id'=> $value['id_persona'],
						);
						//var_dump($usuario);

						// Modifica el usuario
						$db->where('id_user', $value['id_user'])->update('sys_users', $usuario_tutores);
				  
                    }
		        }

            }

			// Verifica si es creacion o modificacion  C = Creacion y A = Actualizar ; P = Programado y CG = Contraseña generica
			// if ($rol_id == 5 && $accion_usuario == 'C' && $tipo_contrasenia == 'P') {
				
			// 	//var_dump($_POST);exit();
			// 	$estudiantes=$db->query("SELECT * FROM ins_inscripcion i
			// 	INNER JOIN ins_estudiante e ON i.estudiante_id=e.id_estudiante
			// 	INNER JOIN ins_inscripcion_rude r ON i.estudiante_id=r.ins_estudiante_id
			// 	inner join sys_persona sp on e.persona_id=sp.id_persona
			// 	WHERE i.estado = 'A' AND i.gestion_id = $gestion_id")->fetch();

			// 	foreach ($estudiantes as $key => $value) {

		 //        	///////////////////////////////////////////////////////////////////////
		 //        	$nombre_estudiante  = $value['nombres'];
			// 		if($value['primer_apellido']!=''){
   //                       $primer_apellido 	= $value['primer_apellido'];
			// 		}else{
			// 			 $primer_apellido 	= $value['segundo_apellido'];
			// 		}

		 //        	$find = array('Á','É','Í','Ó','Ú','Ñ','ñ','á','é','í','ó','ú');
			// 		$repl = array('A','E','I','O','U','N','N','A','E','I','O','U');

			// 		$nombre_estudiante  = str_replace($find, $repl, $nombre_estudiante);
			// 		$primer_apellido    = str_replace($find, $repl, $primer_apellido);

	  //               $nuevo_nombre_estudiante  = clear(strtoupper($nombre_estudiante));
	  //               $nuevo_primer_apellido    = clear(strtoupper($primer_apellido));

		 //        	//$nuevo_rude 	= substr(clear($nro_rude), 0, -1);				        	
		 //        	//$resultado_rude = substr($nuevo_rude, 8);
		        	
			// 		$nombre 		= explode(" ", $nuevo_nombre_estudiante);
	  //               $username 		= $nombre[0];

	  //               //$letra_nivel  = $nombre_nivel[0];
	  //               //$password 	= $nuevo_rude;

	  //               if($value['nro_rude']!=''){
   //                      $nro_rude 	= clear($value['nro_rude']);
   //                  }else{
   //                      //$nro_rude 	= clear($value['numero_documento']);
   //                      $nro_rude 	= clear($value['numero_documento']).'M';
   //                  }

	  //               $password 	    = $nro_rude;
	  //               //////////////////////////////////////////////////////////////////////////

			// 		// Instancia el usuario
			// 		$usuario = array(
			// 			'username'	=> $username.'.'.$nuevo_primer_apellido,
			// 			'password' 	=> encrypt($password),
			// 			'email' 	=> '',
			// 			'active' 	=> 's',
			// 			'avatar' 	=> '',
			// 			'visible' 	=> 's',
			// 			'rol_id' 	=> $rol_id,
			// 			'persona_id'=> $value['persona_id'],
			// 			'gestion_id'=> $gestion_id,
			// 			'token' 	=> '',
			// 			'imei' 		=> '',
			// 			'login_at' 	=> '0000-00-00 00:00:00',
			// 			'logout_at' => '0000-00-00 00:00:00',
			// 		);

			// 		// Crea el usuario
			// 		$id_usuario = $db->insert('sys_users', $usuario);

			// 		// Guarda el proceso
			// 		// $db->insert('sys_procesos', array(
			// 		// 	'fecha_proceso'	=> date('Y-m-d'),
			// 		// 	'hora_proceso' 	=> date('H:i:s'),
			// 		// 	'proceso' 		=> 'c',
			// 		// 	'nivel' 		=> 'm',
			// 		// 	'detalle' 		=> 'Se creó el usuario con rol estudiante con identificador número ' . $id_usuario . '.',
			// 		// 	'direccion' 	=> $_location,
			// 		// 	'usuario_id' 	=> $_user['id_user']
			// 		// ));
			// 	}

			// 	// Crea la notificacion
			// 	set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 	// Redirecciona la pagina
			// 	redirect('?/usuarios/listar');
			// }else if ($rol_id == 5 && $accion_usuario == 'A' && $tipo_contrasenia == 'P') {
   //              //var_dump('expression');
   //              //var_dump($_POST);exit();
			// 	$estudiantes=$db->query("SELECT u.id_user, r.nro_rude, u.rol_id, sp.numero_documento
			// 	FROM ins_estudiante e 
			// 	INNER JOIN ins_inscripcion_rude r ON e.id_estudiante = r.ins_estudiante_id
			// 	inner join sys_persona sp on e.persona_id = sp.id_persona				
			// 	inner join sys_users u on sp.id_persona = u.persona_id
			// 	WHERE  u.rol_id = 5 ")->fetch();
			// 	//var_dump($estudiantes);exit();

			// 	foreach ($estudiantes as $key => $value) {

   //                  ///////////////////////////////////////////////////////////////////////
		 //        	$nombre_estudiante  = $value['nombres'];
			// 		if($value['primer_apellido']!=''){
   //                       $primer_apellido 	= $value['primer_apellido'];
			// 		}else{
			// 			 $primer_apellido 	= $value['segundo_apellido'];
			// 		}

		 //        	$find = array('Á','É','Í','Ó','Ú','Ñ','ñ','á','é','í','ó','ú');
			// 		$repl = array('A','E','I','O','U','N','N','A','E','I','O','U');

			// 		$nombre_estudiante  = str_replace($find, $repl, $nombre_estudiante);
			// 		$primer_apellido    = str_replace($find, $repl, $primer_apellido);

	  //               $nuevo_nombre_estudiante  = clear(strtoupper($nombre_estudiante));
	  //               $nuevo_primer_apellido    = clear(strtoupper($primer_apellido));

		 //        	//$nuevo_rude 	= substr(clear($nro_rude), 0, -1);				        	
		 //        	//$resultado_rude = substr($nuevo_rude, 8);
		        	
			// 		$nombre 		= explode(" ", $nuevo_nombre_estudiante);
	  //               $username 		= $nombre[0];

	  //               //$letra_nivel  = $nombre_nivel[0];
	  //               //$password 	= $nuevo_rude;

			// 		if($value['nro_rude']!=''){
   //                      $nro_rude 	= clear($value['nro_rude']);
   //                  }else{
   //                      //$nro_rude 	= clear($value['numero_documento']);
   //                      $nro_rude 	= clear($value['numero_documento']).'M';
   //                  }

	  //               $password 	    = $nro_rude;
	  //               //////////////////////////////////////////////////////////////////////////
				    
			// 	    $id_user	= $value['id_user'];
			// 	    $id_rol		= $value['rol_id'];

			// 		// Instancia el usuario
			// 		$usuario = array(
			// 			'username'	=> $username.'.'.$nuevo_primer_apellido,
			// 			'password' 	=> encrypt($password),
			// 			//'avatar' 	=> '',
			// 			'rol_id' 	=> $rol_id,
			// 			'persona_id'=> $value['persona_id'],
			// 			'gestion_id'=> $gestion_id,
			// 		);

   //                  // Modifica el usuario
			// 	    $db->where('id_user', $id_user)->update('sys_users', $usuario);

			// 		// Guarda el proceso
			// 			// $db->insert('sys_procesos', array(
			// 			// 	'fecha_proceso'	=> date('Y-m-d'),
			// 			// 	'hora_proceso' 	=> date('H:i:s'),
			// 			// 	'proceso' 		=> 'u',
			// 			// 	'nivel' 		=> 'm',
			// 			// 	'detalle' 		=> 'Se actualizó el usuario con rol estudiante con identificador número ' . $id_usuario . '.',
			// 			// 	'direccion' 	=> $_location,
			// 			// 	'usuario_id' 	=> $_user['id_user']
			// 			// ));
			// 	    //var_dump($password,$id_user,$id_rol);
			// 	}
   //              //exit();
			// 	// Crea la notificacion
			// 	set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 	// Redirecciona la pagina
			// 	redirect('?/usuarios/listar');
			// 	}else if ($rol_id == 5 && $accion_usuario == 'C' && $tipo_contrasenia == 'CG') {
			// 		var_dump($_POST);exit();
			// 		$estudiantes=$db->query("SELECT * FROM ins_inscripcion i
			// 		INNER JOIN ins_estudiante e ON i.estudiante_id=e.id_estudiante
			// 		INNER JOIN ins_inscripcion_rude r ON i.estudiante_id=r.ins_estudiante_id
			// 		inner join sys_persona sp on e.persona_id=sp.id_persona
			// 		WHERE i.estado = 'A' AND i.gestion_id = $gestion_id and u.rol_id = 5 ")->fetch();

			// 		foreach ($estudiantes as $key => $value) {

			// 		    //$password 	= clear($value['nro_rude']);
			// 			$nombre 	= explode(" ", $value['nombres']);
	  //                   $username 	= $nombre[0];

			// 			// Instancia el usuario
			// 			$usuario = array(
			// 				'username'	=> $username.'.'.$value['primer_apellido'],
			// 				'password' 	=> encrypt($passwordg),
			// 				'email' 	=> '',
			// 				'active' 	=> 's',
			// 				'avatar' 	=> '',
			// 				'visible' 	=> 's',
			// 				'rol_id' 	=> $rol_id,
			// 				'persona_id'=> $value['persona_id'],
			// 				'gestion_id'=> $gestion_id,
			// 				'token' 	=> '',
			// 				'imei' 		=> '',
			// 				'login_at' 	=> '0000-00-00 00:00:00',
			// 				'logout_at' => '0000-00-00 00:00:00',
			// 			);

			// 			// Crea el usuario
			// 			//$id_usuario = $db->insert('sys_users', $usuario);

			// 			// Guarda el proceso
			// 			$db->insert('sys_procesos', array(
			// 				'fecha_proceso'	=> date('Y-m-d'),
			// 				'hora_proceso' 	=> date('H:i:s'),
			// 				'proceso' 		=> 'c',
			// 				'nivel' 		=> 'm',
			// 				'detalle' 		=> 'Se creó el usuario con rol estudiante con identificador número ' . $id_usuario . '.',
			// 				'direccion' 	=> $_location,
			// 				'usuario_id' 	=> $_user['id_user']
			// 			));
			// 		}

			// 		// Crea la notificacion
			// 		set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 		// Redirecciona la pagina
			// 		redirect('?/usuarios/listar');
			// 	}else if ($rol_id == 5 && $accion_usuario == 'A' && $tipo_contrasenia == 'CG') {
			// 		var_dump($_POST);exit();
			//     	$estudiantes=$db->query("SELECT * FROM ins_inscripcion i
			// 		INNER JOIN ins_estudiante e ON i.estudiante_id=e.id_estudiante
			// 		INNER JOIN ins_inscripcion_rude r ON i.estudiante_id=r.ins_estudiante_id
			// 		inner join sys_persona sp on e.persona_id=sp.id_persona
			// 		WHERE i.estado = 'A' AND i.gestion_id = $gestion_id and u.rol_id = 5 ")->fetch();
	  //                var_dump('expressionfdfdfs');exit();
			// 		foreach ($estudiantes as $key => $value) {

			// 		    //$password 	= clear($value['nro_rude']);
			// 		    $id_user	= $val['id_user'];

			// 			// Instancia el usuario
			// 			$usuario = array( 'password' 	=> encrypt($passwordg) );

	  //                   // Modifica el usuario
			// 		    //$db->where('id_user', $id_user)->update('sys_users', $usuario);

			// 			// Guarda el proceso
			// 				// $db->insert('sys_procesos', array(
			// 				// 	'fecha_proceso'	=> date('Y-m-d'),
			// 				// 	'hora_proceso' 	=> date('H:i:s'),
			// 				// 	'proceso' 		=> 'u',
			// 				// 	'nivel' 		=> 'm',
			// 				// 	'detalle' 		=> 'Se actualizó el usuario con rol estudiante con identificador número ' . $id_usuario . '.',
			// 				// 	'direccion' 	=> $_location,
			// 				// 	'usuario_id' 	=> $_user['id_user']
			// 				// ));
			// 		}

			// 		// Crea la notificacion
			// 		set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 		// Redirecciona la pagina
			// 		redirect('?/usuarios/listar');
			    
			//     }else if ($rol_id == 3 && $accion_usuario == 'C' && $tipo_contrasenia == 'P') {

			// 		$docentes=$db->query("SELECT sp.numero_documento, sp.id_persona, u.persona_id, sp.nombres, u.id_user
			// 		FROM sys_users u
			// 		inner join sys_persona sp on u.persona_id=sp.id_persona
			// 		WHERE u.rol_id = 3 ")->fetch();

			// 		foreach ($docentes as $val) {
	                    
	  //                    $password = clear($val['numero_documento']);
	  //                    $id_user=$val['id_user'];

			// 			// Instancia el usuario
			// 			$data = array(
			// 				'password' 	=>  encrypt($password),
			// 			);
						
	  //                  // Modifica el usuario
			// 		    $db->where('id_user', $id_user)->update('sys_users', $data);

			// 			// Guarda el proceso
			// 				// $db->insert('sys_procesos', array(
			// 				// 	'fecha_proceso'	=> date('Y-m-d'),
			// 				// 	'hora_proceso' 	=> date('H:i:s'),
			// 				// 	'proceso' 		=> 'u',
			// 				// 	'nivel' 		=> 'm',
			// 				// 	'detalle' 		=> 'Se actualizo el usuario con rol docente con identificador número ' . $id_usuario . '.',
			// 				// 	'direccion' 	=> $_location,
			// 				// 	'usuario_id' 	=> $_user['id_user']
			// 				// ));
			// 		}

			// 		// Crea la notificacion
			// 		set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 		// Redirecciona la pagina
			// 		redirect('?/usuarios/listar');
			// 	}else if ($rol_id == 3 && $accion_usuario == 'A' && $tipo_contrasenia == 'P') {

			// 		$docentes=$db->query("SELECT sp.numero_documento, sp.id_persona, u.persona_id, sp.nombres, u.id_user
			// 		FROM sys_users u
			// 		inner join sys_persona sp on u.persona_id=sp.id_persona
			// 		WHERE u.rol_id = 3 ")->fetch();

			// 		foreach ($docentes as $val) {
	                    
	  //                    $password = clear($val['numero_documento']);
	  //                    $id_user=$val['id_user'];

			// 			// Instancia el usuario
			// 			$data = array(
			// 				'password' 	=>  encrypt($password),
			// 			);
						
	  //                  // Modifica el usuario
			// 		    $db->where('id_user', $id_user)->update('sys_users', $data);

			// 			// Guarda el proceso
			// 				// $db->insert('sys_procesos', array(
			// 				// 	'fecha_proceso'	=> date('Y-m-d'),
			// 				// 	'hora_proceso' 	=> date('H:i:s'),
			// 				// 	'proceso' 		=> 'u',
			// 				// 	'nivel' 		=> 'm',
			// 				// 	'detalle' 		=> 'Se actualizo el usuario con rol docente con identificador número ' . $id_usuario . '.',
			// 				// 	'direccion' 	=> $_location,
			// 				// 	'usuario_id' 	=> $_user['id_user']
			// 				// ));
			// 		}

			// 		// Crea la notificacion
			// 		set_notification('success', 'Creación exitosa!', 'El registro se creó satisfactoriamente.');

			// 		// Redirecciona la pagina
			// 		redirect('?/usuarios/listar');
			// 	}else if ($rol_id == 3 && $accion_usuario == 'C' && $tipo_contrasenia == 'CG') {
			// 	}else if ($rol_id == 3 && $accion_usuario == 'A' && $tipo_contrasenia == 'CG') {
			// 	}else {
			// 	var_dump($_POST);exit();

			// 	// Instancia el usuario
			// 	// $usuario = array(
			// 	// 	'username'	=> $username,
			// 	// 	'password' 	=> encrypt($password),
			// 	// 	'email' 	=> $email,
			// 	// 	'active' 	=> 's',
			// 	// 	'visible' 	=> 's',
			// 	// 	'rol_id' 	=> $rol_id,
			// 	// 	'persona_id'=> $persona_id,
			// 	// 	'gestion_id'=> $gestion_id
			// 	// );

			// 	// // Crea el usuario
			// 	// $id_usuario = $db->insert('sys_users', $usuario);

			// 	// // Guarda el proceso
			// 	// $db->insert('sys_procesos', array(
			// 	// 	'fecha_proceso'	=> date('Y-m-d'),
			// 	// 	'hora_proceso' 	=> date('H:i:s'),
			// 	// 	'proceso' 		=> 'c',
			// 	// 	'nivel' 		=> 'm',
			// 	// 	'detalle' 		=> 'Se creó el usuario con identificador número ' . $id_usuario . '.',
			// 	// 	'direccion' 	=> $_location,
			// 	// 	'usuario_id' 	=> $_user['id_user']
			// 	// ));

			// 	// Crea la notificacion
			// 	set_notification('warning', 'Advertencia!', 'verifique que el rol este habilitado.');

			// 	// Redirecciona la pagina
			// 	redirect('?/usuarios/listar');
			// }
		} else {
			// Error 400
			require_once bad_request();
			exit;
		}
	} else {
		// Redirecciona la pagina
		redirect('?/usuarios/listar');
	}
} else {
	// Error 404
	require_once not_found();
	exit;
}

?>